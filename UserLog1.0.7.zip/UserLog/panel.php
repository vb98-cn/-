<?php

include 'header.php';
include 'menu.php';
date_default_timezone_set("Asia/Chongqing"); // PRC为中华人名共和国
$y = date("Y");
$n = date("n");
$j = date("Ynj");//今天
$z = date("Ynj",strtotime("-1 day"));//昨天
$jsonFile=__DIR__ . '/history/all.json';

if (!file_exists($jsonFile)){
$jsonData = json_encode(array());
file_put_contents($jsonFile,$jsonData);
}
$json = file_get_contents($jsonFile);
$data = json_decode($json);

?>
<style>
    ul.typecho-option-tabs button {
    margin-right: -1px;
    border: 1px solid #3f51b5;
    padding: 0 15px;
    height: 26px;
    line-height: 26px;
    color: #fff;
    box-sizing: border-box;
    background: #2196f3;
    cursor: pointer;
}
.typecho-option-tabs {
    white-space: nowrap;
    overflow-x: auto;
    overflow-y: hidden;
    text-align: left;
}
.typecho-option-tabs li {
    float: none;
    display: inline-block;
}
.typecho-option-tabs li.current button, .typecho-option-tabs li.active button {
    background-color: #3f51b5;
}
#user-合计 th{border:none}
#user-合计 span {
    color: #ff4d4d;
    font-size: 24px;
    margin: 2px;
}
</style>
<div class="main" x-data="{loginnum:'0',usernum:'0',num:'0',year:'<?php echo $y; ?>',month:'<?php echo $n; ?>',ymd:'<?php echo $j; ?>',ym:''}"
@tj="//这里js函数是ChatGPT写的，用来统计本年度登录人数的
tableRows = document.getElementsByTagName('tr'); 
uniqueItemsSet = new Set(); 

for (let i = 0; i < tableRows.length; i++) { 
  const rowCells = tableRows[i].getElementsByTagName('td'); 
  for (let j = 0; j < rowCells.length; j++) { 
    uniqueItemsSet.add(rowCells[0].innerText); 
  } 
} 

uniqueItemsCount = uniqueItemsSet.size; // 
usernum=uniqueItemsCount;
console.log(usernum);
loginnum=$('.zeinfo').length;
if(loginnum>0){
num=(loginnum/usernum).toFixed(2);
}
"
    >
    <div class="body container">
            <div class="body container">
        <div class="typecho-page-title">
<h2>用户日志</h2>
</div>
        <div class="row typecho-page-main" role="main">
            <div class="col-mb-12 typecho-list">
<div class="clearfix">
<div>
<ul class="typecho-option-tabs">
<li :class="{'current': ymd=='<?php echo $j; ?>'}">
<button @click="ym=false;month=0;ymd='<?php echo $j; ?>';$nextTick(() => { $dispatch('tj'); });">今天</button>
</li><li :class="{'current': ymd=='<?php echo $z; ?>'}">
<button @click="ym=false;month=0;ymd='<?php echo $z; ?>';$nextTick(() => { $dispatch('tj'); });">昨天</button>
</li><template x-for="i in 5">
<li x-data="{y:year-i+1}" :class="{'current': y==year&&!ymd}">
    <button @click="year=y;month='<?php echo $n; ?>';ym=year+''+month;ymd=false;$nextTick(() => { $dispatch('tj'); });" x-text="y+'年'"></button></li>
</template>
</ul></div>

<ul class="typecho-option-tabs">
<template x-for="i in 13">
<li x-data="{text:i+'月'}" x-init="if(i==13){text='全部';}"
:class="{'current': month==i&&!ymd}"><button @click="month=i;ym=year+''+month;ymd=false;
$nextTick(() => { $dispatch('tj'); });
" x-text="text"></button></li>
</template>

</ul>
</div>
                
<div class="typecho-table-wrap" style="
    max-height: 70vh;
    overflow-y: auto;
    margin-top: 10px;
">
<table class="typecho-list-table">

<colgroup>
        <col width="15">
        <col width="20">
        <col width="25">
        <col width="20">
        <col width="20">
</colgroup>
  <thead>
    <template x-if="month==13">
       <tr id="user-合计">
       <th colspan="5">
       <span x-text="year"></span>年合计共有<span x-text="usernum"></span>名用户登录，共计登录<span x-text="loginnum"></span>次，平均每人登录<span x-text="num"></span>次。
       </th>
       </tr>
    </template>
    <tr>
      <th>用户uid</th>
      <th>用户名</th>
      <th>昵称</th>
      <th>登录时间</th>
      <th>登录方式</th>
    </tr>
  </thead>
  <tbody>
      

      
    <?php
    if(empty($data)){
        echo '<tr><td colspan="5">暂无任何数据</td></tr>';
    }else{

    foreach($data as $day => $days){
      ?>
      <template x-if="ymd=='<?php echo date("Ynj", $days->times); ?>'||ym=='<?php echo date("Yn", $days->times); ?>'||(month==13&&year=='<?php echo date("Y", $days->times); ?>')">
        <tr class="zeinfo">
        <td><?php echo $days->uid ?></td>
        <td><?php echo $days->name ?></td>
        <td><?php echo $days->screenName ?></td>
        <td><?php echo date("Y年n月j日 H:i", $days->times); ?></td>
        <td><?php if($days->status=='0'){echo '常规登录';}else{echo '<span style="color:red">插件登录</span>'; } ?></td>
        </tr>
      </template>
      <?php 
    }
    }
    ?>
           

  </tbody>
</table>

</div></div>
</div></div></div>
</div></div>

<?php

include 'copyright.php';
include 'common-js.php';
include 'footer.php';
?>
<script src="https://cdn.staticfile.org/alpinejs/3.10.5/cdn.min.js" defer></script>
